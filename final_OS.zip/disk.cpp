#include <iostream>                                 // final project by Alice Amos ID:315511493
#include <vector>
#include <map>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

using namespace std;

#define DISK_SIZE 256


void decToBinary(int n , char &c) {                 // method to convert a number in decimal base to binary 
    
    int binaryNum[8];                               // array to store binary number
  
     
    int i = 0;                                      // counter for binary array  
    while (n > 0) {                                 
           
        binaryNum[i] = n % 2;                       // storing remainder in binary array
        n = n / 2; 
        i++; 
    } 
  
     
    for (int j = i - 1; j >= 0; j--) {              // printing binary array in reverse order
        if (binaryNum[j]==1)
            c = c | 1u << j;
    }
} 

// #define SYS_CALL
// ============================================================================
class fsInode {                                     // class that holds information about the file
    
    int fileSize;                                   
    int maxFileSize;                                // according to the amount of direct blocks and the size of each block, determine the max size a file can get
    int *directBlocks;                              // pointer to an array that holds the numbers of the blocks that were allocated directly
    int singleInDirect;                             // holds the number of the indirect block
    int num_of_direct_blocks;
    int block_size;


    public:
    
        fsInode(int _block_size, int _num_of_direct_blocks) {                   // constructor, sets all the varaiables
            fileSize = 0;                                                        
            block_size = _block_size;
            num_of_direct_blocks = _num_of_direct_blocks;
            maxFileSize = (num_of_direct_blocks + block_size)*block_size;       // direct blocks + block of indirect blocks
            directBlocks = new int[num_of_direct_blocks];                       // allocate an array for the direct blocks              
		    assert(directBlocks);                                               // allocation check
            for (int i = 0 ; i < num_of_direct_blocks; i++) {                   // at first, no blocks are allocated
                directBlocks[i] = -1;
            }
            singleInDirect = -1;
        }

        // setters and getters
        int getFileSize(){
            return fileSize;
        }

        void setFileSize(int size){
            fileSize = size;
        }

        int* getDirectBlocks(){
            return directBlocks;
        }

        void setDirectBlocks(int* DBlocks){
            directBlocks = DBlocks;
        }

        int getNumOfDirectBlocks(){
            return num_of_direct_blocks;
        }

        void setNumOfDirectBlocks(int num){
            num_of_direct_blocks = num;
        }

        int getSingleInDirect(){
            return singleInDirect;
        }

        void setSingleInDirect(int n){
            singleInDirect = n;
        }

        int getMaxFileSize(){
            return maxFileSize;
        }

        void setMaxFileSize(int n){
            maxFileSize = n;
        }

        ~fsInode() {                                                        // destructor
            delete directBlocks;
        }
};

// ============================================================================
class FileDescriptor {                                      // class that holds information about the file descriptor according the file's name
    
    pair<string, fsInode*> file;                            // pair with the file's name and a pointer to the file's Inode
    bool inUse;                                             // true if the file is open
    bool isDeleted;                                         // true if the file was deleted

    public:
        FileDescriptor(string FileName, fsInode* fsi) {     // constructor, sets all varaiables
            file.first = FileName;
            file.second = fsi;
            inUse = true;
            isDeleted = false;
        }

        // setters and getters
        string getFileName() {
            return file.first;
        }

        void setFileName(string fileName){
            file.first = fileName;
        }

        fsInode* getInode() {
            return file.second;
        }

        void setInode(fsInode* fileNode){
            file.second = fileNode;
        }

        bool isInUse() { 
            return (inUse); 
        }
        
        void setInUse(bool _inUse) {
            inUse = _inUse ;
        }

        bool getIsDeleted() { 
            return isDeleted; 
        }
        
        void setIsDeleted(bool deleted) {
            isDeleted = deleted; 
        }
};
 
#define DISK_SIM_FILE "DISK_SIM_FILE.txt"
// ============================================================================
class fsDisk {                                                  // class that simulates the disk itself
    FILE *sim_disk_fd;                                          // pointer to the "disk's" file descriptor
 
    bool is_formated;                                           // true if the disk was formated (option 2)                                        
    int *BitVector;                                             // pointer to BitVector - array that indicates which block in the disk is free or not, the index is the number of the block
    int BitVectorSize;                                          // the size of this array (amount of possible blocks in the disk)

    map<string, fsInode*>  MainDir ;                            // simulates directory - map that holds all pairs with file name and its Inode  
 
    vector< FileDescriptor > OpenFileDescriptors;               // vector of file descriptors, each file has its fd which is the index in that vector

    int direct_enteris;                                         // amount of direct blocks
    int block_size;

    public:
    // ------------------------------------------------------------------------
    fsDisk() {                                                  // constructor, sets all varaiables
        sim_disk_fd = fopen( DISK_SIM_FILE , "r+" );
        assert(sim_disk_fd);
        for (int i=0; i < DISK_SIZE ; i++) {
            int ret_val = fseek ( sim_disk_fd , i , SEEK_SET );
            ret_val = fwrite( "\0" ,  1 , 1, sim_disk_fd );
            assert(ret_val == 1);
        }
        fflush(sim_disk_fd);
    }

    int getFreeBlock(){                                         // method to assert a free block from the Bitvector
        
        for(int i=0; i<BitVectorSize; i++){                     // go over the Bitvector
            if(BitVector[i] == 0){                              // 0 means the block is free

                BitVector[i] = 1;                               // update it to an occupied block
                return i;                                       // return the number of the block
            }
        }
    }

    // ------------------------------------------------------------------------
    void listAll() {                                            // method to list and print all the content on the disk
        int i = 0;    
        for ( auto it = begin (OpenFileDescriptors); it != end (OpenFileDescriptors); ++it) {
            cout << "index: " << i << ": FileName: " << it->getFileName() <<  " , isInUse: " << it->isInUse() << endl; 
            i++;
        }
        char bufy;
        cout << "Disk content: '" ;
        for (i=0; i < DISK_SIZE ; i++) {
            int ret_val = fseek ( sim_disk_fd , i , SEEK_SET );
            ret_val = fread(  &bufy , 1 , 1, sim_disk_fd );
             cout << bufy;              
        }
        cout << "'" << endl;
    }
 
    // ------------------------------------------------------------------------
    void fsFormat(int blockSize = 4, int direct_Enteris_ = 3) {                 // method to format the disk with default values

        BitVectorSize = DISK_SIZE/blockSize;                                    // amount of blocks - which is disk size/block size
        BitVector = new int[BitVectorSize];                                     // allocate the array

        for(int i=0; i<BitVectorSize; i++){                                     // at first, all blocks are free
            BitVector[i] = 0;
        }

        direct_enteris = direct_Enteris_;
        block_size = blockSize;

        cout << "FORMAT DISK: num of blocks: " << BitVectorSize << endl;
        
        is_formated = true;
    }

    // ------------------------------------------------------------------------
    int CreateFile(string fileName) {                                            // method to create a file

        for(int i=0; i<OpenFileDescriptors.size(); i++){                         // go over the file descriptors
            if(OpenFileDescriptors[i].getFileName().compare(fileName) == 0){     // in case there is already a file with that name
                if(OpenFileDescriptors[i].getIsDeleted() == true)                // in case there was a file with the same name but was deleted
                    break;                                                       // index is found
                else
                    return -1;                                                   // if it wasn't deleted, cannot create a file that is already exists
            }
        }
        
        fsInode* fNode = new fsInode(block_size, direct_enteris);               // new Inode for the file
        pair<string, fsInode*> toMap;
        toMap.first = fileName;                                                 // set the pair to that file's name and pointer to Inode
        toMap.second = fNode;
        
        MainDir.insert(toMap);                                                  // insert the pair represents the new file to the map (directory)
        
        FileDescriptor fileFd = FileDescriptor(fileName, fNode);                // create a file descriptor to the new file 
        
        int i;
        for(i=0; i< OpenFileDescriptors.size(); i++){                           // go over the file descriptors

            if(OpenFileDescriptors[i].getIsDeleted() == true && OpenFileDescriptors[i].isInUse() == false){     // in case the file was deleted, set the fd to the new file
                
                OpenFileDescriptors[i].setFileName(fileName);
                OpenFileDescriptors[i].setInode(fNode);
                OpenFileDescriptors[i].setInUse(true);                          
                OpenFileDescriptors[i].setIsDeleted(false);
                return i;
            }
        }
        
        
        OpenFileDescriptors.push_back(fileFd);                                  // insert the fd of the new file to the file descriptors' vector
        fileFd.setInUse(true);

        return OpenFileDescriptors.size()-1;                                    // the last index is the fd number of the new file   
    }

    // ------------------------------------------------------------------------
    int OpenFile(string fileName) {                                         // method to open an existing file
        
        int i,fdIdx;
        for(i=0; i<OpenFileDescriptors.size(); i++){                                // go over the file descriptors to find the fd number of the file
            if(OpenFileDescriptors[i].getFileName().compare(fileName) == 0){        // in case the file is found
                fdIdx = i;                                                          // hold the index
                break;
            }
        }

        if(i == OpenFileDescriptors.size()){                                   // end of the loop means there is no such file matches that name
            perror("no such file in directory");
            return -1;
        }

        else if(OpenFileDescriptors[fdIdx].isInUse() == true){                 // the file is already open
            perror("the file is already open");
            return -1;
        }

        OpenFileDescriptors[fdIdx].setInUse(true);                            // update the file to an open one (used)
        
        return fdIdx;                                                         // return the fd number of the file
    }  

    // ------------------------------------------------------------------------
    string CloseFile(int fd) {                                                   // method to close an existing file with that fd

        if(fd > (OpenFileDescriptors.size()-1) || fd < 0){                       // the fd is not in range, there is no such file
            perror("file descriptor invalid. no such file");
            return "-1";
        }
        
        else if(OpenFileDescriptors[fd].isInUse() == false){                     // the file is already closed
            perror("the file is already closed");
            return "-1";
        }

        OpenFileDescriptors[fd].setInUse(false);                                // update the file is closed
        
        return OpenFileDescriptors[fd].getFileName();                           // return the name of the file we just closed
    }
    
    // ------------------------------------------------------------------------
    int WriteToFile(int fd, char *buf, int len ) {                              // method to write buf (which its length is len) to a file with that fd

        if(fd > (OpenFileDescriptors.size()-1) || fd < 0){                      // the fd is not in range, there is no such file
            perror("file descriptor invalid. no such file");
            return -1;
        }

        if(is_formated == false){                                                // cannot write to a file without the disk being formated
            perror("the disk is not formated");
            return -1;
        }

        if(OpenFileDescriptors[fd].isInUse() == false){                          // cannot write to a closed file
            perror("cannot write to a closed file");
            return -1;
        }

        fsInode* fNode = OpenFileDescriptors[fd].getInode();                     // get the Inode of the file
        
        if(fNode->getFileSize()+len > fNode->getMaxFileSize()){                  // in case there is not enough space in that file
            perror("not enough space in that file");
            return -1;
        }

        char* copy = (char*)malloc(sizeof(char));                                // allocate 2 arrays of 1 char to read and write
        assert(copy);                                                            // allocation check
        char* data = (char*)malloc(sizeof(char));
        assert(data);
        
        int k=0;                                                                 // counter for the characters we write
        for(int i=0; i<fNode->getNumOfDirectBlocks(); i++){                      // go over the direct blocks

            if(k < len){                                                         // as long there are more characters left to write
                
                if(fNode->getDirectBlocks()[i] == -1){                           // in case there is no direct block asserted to that
                    fNode->getDirectBlocks()[i] = getFreeBlock();                // allocate a new free block
                }

                for(int b_char=0; b_char<block_size; b_char++){                  // go over the block
                    
                    lseek(sim_disk_fd->_fileno, fNode->getDirectBlocks()[i]*block_size + b_char, SEEK_SET);     // get the courser to the right spot (depends on the number of the block + offset)
                    if(read(sim_disk_fd->_fileno, data, 1) == -1)               // read the char to data
                        perror("couldn't read from file");
                
                    if(data[0] == '\0' && k<len){                               // in case there is a free space there  and there are more characters left to write
                        copy[0] = buf[k];                                       // copy the right character from buf to copy
                        lseek(sim_disk_fd->_fileno, fNode->getDirectBlocks()[i]*block_size + b_char, SEEK_SET);  // get the courser to the right spot
                        if(write(sim_disk_fd->_fileno, copy, 1) == -1)          // write the char from copy to the disk
                            perror("couldn't write to the file");
                        
                        k++;                                                    // update the counter
                        fNode->setFileSize(fNode->getFileSize()+1);             // update the file size
                    }
                }
                BitVector[(fNode->getDirectBlocks()[i])] = 1;                   // after going over a block, we can mark it as occupied (or nothing was coppied to it, so it was already occupied and it held '1' anyway)
            }
        }

        if(k < len){                                                            // at this point, we finished going over all the direct blocks and there is no space there to write the rest of the buf - moving on to single indirect block

            if(fNode->getSingleInDirect() == -1)                                // in case there is no single indirect block yet
                fNode->setSingleInDirect(getFreeBlock());                       // assert one free block
            
            for(int inD_block=0; inD_block<block_size && k<len; inD_block++){   // go over that single indirect block - each character here represent a number of a block
                
                lseek(sim_disk_fd->_fileno, fNode->getSingleInDirect()*block_size + inD_block, SEEK_SET);   // get the courser to the right spot
                if(read(sim_disk_fd->_fileno, data, 1) == -1)                   // read the char to data
                    perror("couldn't read from file");

                char inDrct_block = data[0];                                    // save that char
                if(inDrct_block == '\0' && k<len){                              // in case it is empty
                    decToBinary(getFreeBlock(), inDrct_block);                  // assert new free block and convert its number to a char and put it into the varaiable above
                    
                    copy[0] = inDrct_block;                                     // copy that char 
                    lseek(sim_disk_fd->_fileno, fNode->getSingleInDirect()*block_size + inD_block, SEEK_SET);   // get the courser to the right spot
                    if(write(sim_disk_fd->_fileno, copy, 1) == -1)              // write the char represents the block in the single indirect block
                        perror("couldn't write to the file");
                }

                for(int inD_b_char=0; inD_b_char<block_size; inD_b_char++){     // go ovet that indirect block
                    
                    copy[0] = buf[k];                                           // copy the character from buf
                    int inD_block_num = (int)inDrct_block;                      // convert that char to the block number again by casting to int
                    lseek(sim_disk_fd->_fileno, inD_block_num*block_size + inD_b_char, SEEK_SET);   // get the courser to the right spot
                    if(read(sim_disk_fd->_fileno, data, 1) == -1)               // read a char from the disk to data
                        perror("couldn't read from file");

                    if(data[0] == '\0' && k<len){                               // in case there is free space and more characters to write
                        lseek(sim_disk_fd->_fileno, inD_block_num*block_size + inD_b_char, SEEK_SET);   // get the courser to the right spot
                        if(write(sim_disk_fd->_fileno, copy, 1) == -1)          // write what's in copy to the disk
                            perror("couldn't write to the file");
                        
                        k++;                                                    // update the counter
                        fNode->setFileSize(fNode->getFileSize()+1);             // update the file size
                    }
                }
            }
        }

        free(copy);                                                             // free allocations
        free(data);
    }
        
    // ------------------------------------------------------------------------
    int DelFile( string FileName ) {                                            // method to delete a file with that name

        int i,fdIdx;
        for(i=0; i<OpenFileDescriptors.size(); i++){                            // go over the file descriptors
            if(OpenFileDescriptors[i].getFileName().compare(FileName) == 0){    // in case we found the file with that name
                fdIdx = i;                                                      // save the fd index
                break;
            }
        }

        if(i == OpenFileDescriptors.size()){                                     // end of the loop means there is no such file
            perror("no such file");
            return -1;
        }

        OpenFileDescriptors[fdIdx].setInUse(false);                             // update the file to closed and deleted
        OpenFileDescriptors[fdIdx].setIsDeleted(true);

        fsInode* fNode = OpenFileDescriptors[fdIdx].getInode();                 // get the Inode of that file
        char* set = (char*)malloc(sizeof(char));                                // allocate memory for setting all the blocks it caught

        for(i=0; i<fNode->getNumOfDirectBlocks(); i++){                         // go over the direct blocks of the file

            int block_num = fNode->getDirectBlocks()[i];                        // get the number of the block
            if(block_num != -1){                                                // in case the block is occupied
                BitVector[block_num] = 0;                                       // set it to a free one

                set[0] = '\0';
                for(int j=0; j<block_size; j++){                                // go over the block
                   lseek(sim_disk_fd->_fileno, block_num*block_size + j, SEEK_SET);     // get the courser to the right spot
                    if(write(sim_disk_fd->_fileno, set, 1) == -1)               // write to set all its cells to '\0'
                        perror("couldn't write to the file"); 
                }
            }
        }
        
        if(fNode->getSingleInDirect() != -1){                                   // at this point we finished setting the direct blocks, in case there is also a single indirect block
            
            char* data = (char*)malloc(sizeof(char));                           // allocate space to read the indirect blocks

            for(int inD_block=0; inD_block<block_size; inD_block++){
                
                lseek(sim_disk_fd->_fileno, fNode->getSingleInDirect()*block_size + inD_block, SEEK_SET);   // get the courser to the right spot
                if(read(sim_disk_fd->_fileno, data, 1) == -1)                   // read from the disk to data
                    perror("couldn't read from file");

                int inD_block_num = (int)data[0];                               // convert that character to a number of block
                set[0] = '\0';                                                  // set it to '\0'

                lseek(sim_disk_fd->_fileno, fNode->getSingleInDirect()*block_size + inD_block, SEEK_SET);   // get the courser to the right spot
                    if(write(sim_disk_fd->_fileno, set, 1) == -1)               // write to set all its cells to '\0'
                        perror("couldn't write to the file"); 
                
                if(inD_block_num != '\0'){                                      // in case there are indirect blocks
                    BitVector[inD_block_num] = 0;                               // update those blocks to available

                    for(int j=0; j<block_size; j++){                            // go over the block
                        lseek(sim_disk_fd->_fileno, inD_block_num*block_size + j, SEEK_SET);    // get the courser to the right spot
                        if(write(sim_disk_fd->_fileno, set, 1) == -1)           // write to set all its cells to '\0'
                            perror("couldn't write to the file"); 
                    }
                }  
            }
            free(data);
        }
        free(set);
        fNode->~fsInode();                                                      // call the destructor of that file's Inode
        return fdIdx;
    }
    
    // ------------------------------------------------------------------------
    int ReadFromFile(int fd, char *buf, int len ) {                         // method to read len characters from file with that fd to buf 

        for(int j=0; j<DISK_SIZE; j++){                                     // set buf to '\0'
            buf[j] = '\0';
        } 
      
        if(fd > (OpenFileDescriptors.size()-1) || fd < 0){                     // the fd is not in range, there is no such file
            perror("file descriptor invalid. no such file");
            return -1;
        }

        if(is_formated == false){                                               // cannot read from file if the disk wasn't formated
            perror("the disk is not formated");
            return -1;
        }

        else if(OpenFileDescriptors[fd].isInUse() == false || OpenFileDescriptors[fd].getIsDeleted() == true){                 // cannot read from a closed or deleted file
            perror("cannot read from a closed or unexisting file");
            return -1;
        }

        fsInode* fNode = OpenFileDescriptors[fd].getInode();                    // get the file's Inode
        
        if(len > fNode->getFileSize())                                          // in case the user wants to read more characters than the file's size
            len = fNode->getFileSize();                                         // read the whole file


        int k=0;                                                                // counter for the characters we read
        char* data = (char*)malloc(sizeof(char));                               // allocate memory for the reading char by char
        
        while(k < len){                                                         // as long there are more characters left to read

            for(int i=0; i<fNode->getNumOfDirectBlocks(); i++){                 // go over the direct blocks

                if(fNode->getDirectBlocks()[i] != -1){                          // in case the block is occupied

                    for(int b_char=0; b_char<block_size && k < len; b_char++){  // go over the block
                    
                        lseek(sim_disk_fd->_fileno, fNode->getDirectBlocks()[i]*block_size + b_char, SEEK_SET);    // get the courser to the right spot
                        if(read(sim_disk_fd->_fileno, data, 1) == -1)           // read from the disk to data
                            perror("couldn't read from file");
                
                        
                        if(data[0] != '\0'){                                    // in case there is a character written there
                            buf[k] = data[0];                                   // copy it
                            k++;                                                // update the counter
                        }
                    }
                }
            }

            if(k < len){                                                        // at this point we finished reading from the direct blocks, in case there are more characters to read

                for(int inD_block = 0; inD_block < block_size && k<len; inD_block++){   // go over the single indirect block
                
                    lseek(sim_disk_fd->_fileno, fNode->getSingleInDirect()*block_size + inD_block, SEEK_SET);   // get the courser to the right spot
                    if(read(sim_disk_fd->_fileno, data, 1) == -1)               // read from the disk to data
                        perror("couldn't read from file");

                    char inDrct_block = data[0];                                // save that char we read
                    int inD_block_num = (int)inDrct_block;                      // cast it back to a block number
                    if(inDrct_block != '\0' && k<len){                          // in case there is a block number and more characters to read

                        for(int inD_b_char = 0; inD_b_char < block_size && k < len; inD_b_char++){      // go over the indirect block
                            lseek(sim_disk_fd->_fileno, inD_block_num*block_size + inD_b_char, SEEK_SET);   // get the courser to the right spot
                            if(read(sim_disk_fd->_fileno, data, 1) == -1)       // read from the disk to data
                                perror("couldn't read from file");
                    
                            if(data[0] != '\0'){                                // in case it isn't empty
                                buf[k] = data[0];                               // copy the char to buf
                                k++;                                            // update the counter
                            }
                        }

                    }
                }
            }
        }
        free(data);
    }
};
    
int main() {
    int blockSize; 
	int direct_entries;
    string fileName;
    char str_to_write[DISK_SIZE];
    char str_to_read[DISK_SIZE];
    int size_to_read; 
    int _fd;

    fsDisk *fs = new fsDisk();
    int cmd_;
    while(1) {
        cin >> cmd_;
        switch (cmd_)
        {
            case 0:   // exit
                delete fs;
				exit(0);
                break;

            case 1:  // list-file
                fs->listAll(); 
                break;
          
            case 2:    // format
                cin >> blockSize;
				cin >> direct_entries;
                fs->fsFormat(blockSize, direct_entries);
                break;
          
            case 3:    // creat-file
                cin >> fileName;
                _fd = fs->CreateFile(fileName);
                cout << "CreateFile: " << fileName << " with File Descriptor #: " << _fd << endl;
                break;
            
            case 4:  // open-file
                cin >> fileName;
                _fd = fs->OpenFile(fileName);
                cout << "OpenFile: " << fileName << " with File Descriptor #: " << _fd << endl;
                break;
             
            case 5:  // close-file
                cin >> _fd;
                fileName = fs->CloseFile(_fd); 
                cout << "CloseFile: " << fileName << " with File Descriptor #: " << _fd << endl;
                break;
           
            case 6:   // write-file
                cin >> _fd;
                cin >> str_to_write;
                fs->WriteToFile( _fd , str_to_write , strlen(str_to_write) );
                break;
          
            case 7:    // read-file
                cin >> _fd;
                cin >> size_to_read ;
                fs->ReadFromFile( _fd , str_to_read , size_to_read );
                cout << "ReadFromFile: " << str_to_read << endl;
                break;
           
            case 8:   // delete file 
                 cin >> fileName;
                _fd = fs->DelFile(fileName);
                cout << "DeletedFile: " << fileName << " with File Descriptor #: " << _fd << endl;
                break;
            default:
                break;
        }
    }

} 